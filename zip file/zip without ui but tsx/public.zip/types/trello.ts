// types.ts
export interface ColorPalette {
  bg: string;
  border: string;
  text: string;
}

export interface ChecklistItem {
  text: string;
  done: boolean;
}

export interface Checklist {
  id: string;
  title: string;
  items: ChecklistItem[];
}

export interface Label {
  id: string;
  name: string;
  color: string;
}

export interface Comment {
  text: string;
  time: string;
}

export interface Card {
  name: string;
  description?: string;
  color?: ColorPalette;
  labels?: Label[];
  checklist?: ChecklistItem[];
  checklists?: Checklist[];
  comments?: Comment[];
  activity?: Comment[];
  attachments?: string[];
  startDate?: string;
  dueDate?: string;
  location?: string;
  completed?: boolean;
}

export interface List {
  name: string;
  color?: ColorPalette;
  cards: Card[];
}

export interface Board {
  name: string;
  color?: ColorPalette;
  lists: List[];
}
