import chroma from "chroma-js";

export interface Palette {
  bg: string;
  border: string;
  text: string;
}

export function generatePalette(): Palette {
  // Base random color
  const base = chroma.random().saturate(1.2);

  // Decide readable text color
  const text =
    chroma.contrast(base, "white") > 4.5
      ? "#ffffff"
      : "#111827";

  return {
    bg: base.alpha(0.18).css(),       // soft pastel background
    border: base.darken(0.6).css(),   // visible border
    text,                             // readable text
  };
}
