/* eslint-disable @typescript-eslint/no-unused-vars */
"use client";

import { useState, useRef, useCallback } from "react";
import { DragDropContext, DropResult } from "@hello-pangea/dnd";

import BoardsGrid from "@/components/BoardsGrid";
import BoardView from "@/components/BoardView";
import Modal from "@/components/Modal";
import CardDetailsModal from "@/components/CardDetailsModal";

import { Board, Card } from "@/types/trello";
import useLocalStorageState from "@/hooks/useLocalStorageState";
import { generatePalette } from "@/utils/generatePalette";

/* =======================
   TYPES
======================= */
interface CardLocation {
  boardIndex: number;
  listIndex: number;
  cardIndex: number;
}

/* =======================
   COMPONENT
======================= */
export default function Dashboard() {
  /* ---------- User ---------- */
  const [user] = useState<string>(() => {
    try {
      return localStorage.getItem("loggedInUser") ?? "";
    } catch {
      return "";
    }
  });

  /* ---------- Boards ---------- */
  const [boards, setBoards] = useLocalStorageState<Board[]>(
    `boardsData_${user}`,
    []
  );

  const [selectedBoardIndex, setSelectedBoardIndex] =
    useState<number | null>(null);

  /* ---------- Modal ---------- */
  const [modalOpen, setModalOpen] = useState(false);
  const [modalLabel, setModalLabel] = useState("");
  const [modalValue, setModalValue] = useState("");
  const [modalError, setModalError] = useState("");

  const actionRef = useRef<((value: string) => void) | null>(null);

  /* ---------- Active Card ---------- */
  const [activeCard, setActiveCard] =
    useState<CardLocation | null>(null);

  /* =======================
     MODAL HELPERS
  ======================= */
  const openModal = useCallback(
    (
      label: string,
      action: (value: string) => void,
      initialValue = ""
    ) => {
      setModalLabel(label);
      setModalValue(initialValue);
      setModalError("");
      actionRef.current = action;
      setModalOpen(true);
    },
    []
  );

  const closeModal = useCallback(() => {
    setModalOpen(false);
    actionRef.current = null;
    setModalValue("");
    setModalLabel("");
    setModalError("");
  }, []);

  const submitModal = useCallback(() => {
    const trimmed = modalValue.trim();
    if (!trimmed) {
      setModalError("Name cannot be empty");
      return;
    }

    actionRef.current?.(trimmed);
    closeModal();
  }, [modalValue, closeModal]);

  /* =======================
     DRAG & DROP
  ======================= */
  const onDragEnd = (result: DropResult) => {
    const { source, destination, type } = result;
    if (!destination) return;

    setBoards((prev) => {
      const data = structuredClone(prev);

      if (type === "BOARD") {
        const [moved] = data.splice(source.index, 1);
        data.splice(destination.index, 0, moved);
        return data;
      }

      if (type === "LIST") {
        const from = Number(source.droppableId);
        const to = Number(destination.droppableId);
        const [moved] = data[from].lists.splice(source.index, 1);
        data[to].lists.splice(destination.index, 0, moved);
        return data;
      }

      const [sb, sl] = source.droppableId.split("-").map(Number);
      const [db, dl] = destination.droppableId.split("-").map(Number);

      const [moved] =
        data[sb].lists[sl].cards.splice(source.index, 1);
      data[db].lists[dl].cards.splice(destination.index, 0, moved);

      return data;
    });
  };

  /* =======================
     CARD UPDATE (DETAILS)
  ======================= */
  const updateCard = useCallback(
    (loc: CardLocation, updated: Card) => {
      setBoards((prev) => {
        const copy = structuredClone(prev);
        copy[loc.boardIndex]
          .lists[loc.listIndex]
          .cards[loc.cardIndex] = updated;
        return copy;
      });
    },
    [setBoards]
  );

  /* =======================
     BOARD CRUD
  ======================= */
  const addBoard = useCallback((name: string) => {
    setBoards((prev) => [
      ...prev,
      { name, color: generatePalette(), lists: [] },
    ]);
  }, [setBoards]);

  const editBoard = useCallback(
    (boardIndex: number, name: string) => {
      setBoards((prev) => {
        const copy = [...prev];
        copy[boardIndex] = { ...copy[boardIndex], name };
        return copy;
      });
    },
    [setBoards]
  );

  const deleteBoard = useCallback(
    (boardIndex: number) => {
      if (!window.confirm("Delete this board?")) return;
      setBoards((prev) => prev.filter((_, i) => i !== boardIndex));
      setSelectedBoardIndex(null);
    },
    [setBoards]
  );

  /* =======================
     LIST CRUD
  ======================= */
  const addList = useCallback(
    (boardIndex: number, name: string) => {
      setBoards((prev) => {
        const copy = [...prev];
        copy[boardIndex].lists.push({
          name,
          color: generatePalette(),
          cards: [],
        });
        return copy;
      });
    },
    [setBoards]
  );

  const editList = useCallback(
    (boardIndex: number, listIndex: number, name: string) => {
      setBoards((prev) => {
        const copy = [...prev];
        copy[boardIndex].lists[listIndex] = {
          ...copy[boardIndex].lists[listIndex],
          name,
        };
        return copy;
      });
    },
    [setBoards]
  );

  const deleteList = useCallback(
    (boardIndex: number, listIndex: number) => {
      setBoards((prev) => {
        const copy = [...prev];
        if (copy[boardIndex].lists[listIndex].cards.length > 0) {
          alert("Remove cards first");
          return prev;
        }
        copy[boardIndex].lists.splice(listIndex, 1);
        return copy;
      });
    },
    [setBoards]
  );

  /* =======================
     CARD CRUD
  ======================= */
  const addCard = useCallback(
    (boardIndex: number, listIndex: number, name: string) => {
      setBoards((prev) => {
        const copy = [...prev];
        copy[boardIndex].lists[listIndex].cards.push({
          name,
          color: generatePalette(),
        });
        return copy;
      });
    },
    [setBoards]
  );

  const editCard = useCallback(
    (
      boardIndex: number,
      listIndex: number,
      cardIndex: number,
      name: string
    ) => {
      setBoards((prev) => {
        const copy = [...prev];
        copy[boardIndex].lists[listIndex].cards[cardIndex] = {
          ...copy[boardIndex].lists[listIndex].cards[cardIndex],
          name,
        };
        return copy;
      });
    },
    [setBoards]
  );

  const deleteCard = useCallback(
    (
      boardIndex: number,
      listIndex: number,
      cardIndex: number
    ) => {
      if (!window.confirm("Delete this card?")) return;
      setBoards((prev) => {
        const copy = [...prev];
        copy[boardIndex].lists[listIndex].cards.splice(cardIndex, 1);
        return copy;
      });
    },
    [setBoards]
  );

  /* =======================
     RENDER
  ======================= */
  return (
    <DragDropContext onDragEnd={onDragEnd}>
      {selectedBoardIndex === null ? (
        <BoardsGrid
          boards={boards}
          onSelect={setSelectedBoardIndex}
          onAdd={() =>
            openModal("Add Board", (name) => addBoard(name))
          }
          onEdit={(i) =>
            openModal(
              "Edit Board",
              (name) => editBoard(i, name),
              boards[i].name
            )
          }
          onDelete={(i) => deleteBoard(i)}
        />
      ) : (
        <BoardView
          board={boards[selectedBoardIndex]}
          boardIndex={selectedBoardIndex}
          onBack={() => setSelectedBoardIndex(null)}

          onEditBoard={() =>
            openModal(
              "Edit Board",
              (name) => editBoard(selectedBoardIndex, name),
              boards[selectedBoardIndex].name
            )
          }

          onDeleteBoard={() => deleteBoard(selectedBoardIndex)}

          onAddList={() =>
            openModal("Add List", (name) =>
              addList(selectedBoardIndex, name)
            )
          }

          onEditList={(li, name) =>
            openModal(
              "Edit List",
              (n) => editList(selectedBoardIndex, li, n),
              name
            )
          }

          onDeleteList={(li) =>
            deleteList(selectedBoardIndex, li)
          }

          onAddCard={(li) =>
            openModal("Add Card", (name) =>
              addCard(selectedBoardIndex, li, name)
            )
          }

          onEditCard={(li, ci, name) =>
            openModal(
              "Edit Card",
              (n) =>
                editCard(selectedBoardIndex, li, ci, n),
              name
            )
          }

          onDeleteCard={(li, ci) =>
            deleteCard(selectedBoardIndex, li, ci)
          }

          openModal={openModal}

          onOpenCard={(l, c) =>
            setActiveCard({
              boardIndex: selectedBoardIndex,
              listIndex: l,
              cardIndex: c,
            })
          }
        />
      )}

      {activeCard && (
        <CardDetailsModal
          card={
            boards[activeCard.boardIndex]
              .lists[activeCard.listIndex]
              .cards[activeCard.cardIndex]
          }
          onClose={() => setActiveCard(null)}
          onSave={(updated: Card) => {
            updateCard(activeCard, updated);
            setActiveCard(null);
          }}
        />
      )}

      <Modal
        open={modalOpen}
        label={modalLabel}
        value={modalValue}
        error={modalError}
        onChange={setModalValue}
        onCancel={closeModal}
        onSave={submitModal}
      />
    </DragDropContext>
  );
}
