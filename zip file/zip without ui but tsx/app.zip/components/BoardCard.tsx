"use client";
import React, { memo } from "react";
import EditIcon from "@mui/icons-material/EditNoteOutlined";
import DeleteIcon from "@mui/icons-material/DeleteOutlineOutlined";
import { Draggable } from "@hello-pangea/dnd";
import { Board } from "@/types/trello";

interface Props {
  board: Board;
  index: number;
  onSelect: (index: number) => void;
  onEdit: (index: number) => void;
  onDelete: (index: number) => void;
  onDoubleClick?: (index: number) => void;
}

function BoardCard({
  board,
  index,
  onSelect,
  onEdit,
  onDelete,
  onDoubleClick,
}: Props) {
  return (
    <Draggable draggableId={`board-${index}`} index={index}>
      {(provided) => (
        <article
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          className="board"
          tabIndex={0}
          onClick={() => onSelect(index)}
          onDoubleClick={(e) => {
            e.preventDefault();
            onDoubleClick?.(index);
          }}
          style={{
            ...provided.draggableProps.style,
            backgroundColor: board.color?.bg,
            border: `2px solid ${board.color?.border}`,
            color: board.color?.text,
            display: "flex",
            justifyContent: "space-between",
            padding: 16,
            borderRadius: 8,
          }}
        >
          <strong>{board.name || "Untitled Board"}</strong>

          <div>
            <button
              aria-label="Edit board"
              title="Edit board"
              onClick={(e) => {
                e.stopPropagation();
                onEdit(index);
              }}
            >
              <EditIcon />
            </button>

            <button
              aria-label="Delete board"
              title="Delete board"
              onClick={(e) => {
                e.stopPropagation();
                onDelete(index);
              }}
            >
              <DeleteIcon />
            </button>
          </div>
        </article>
      )}
    </Draggable>
  );
}

export default memo(BoardCard);
