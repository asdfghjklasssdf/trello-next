"use client";
import React, { forwardRef, memo } from "react";

interface Props {
  open: boolean;
  label: string;
  value: string;
  error?: string;
  onChange: (v: string) => void;
  onCancel: () => void;
  onSave: () => void;
}

const Modal = forwardRef<HTMLInputElement, Props>(
  ({ open, label, value, error, onChange, onCancel, onSave }, ref) => {
    if (!open) return null;

    return (
      <div onMouseDown={onCancel}>
        <div onMouseDown={(e) => e.stopPropagation()}>
          <h3>{label}</h3>
<input
  ref={ref}
  aria-label={label}
  placeholder="Enter name"
  value={value}
  onChange={(e) => onChange(e.target.value)}
/>


          {error && <div>{error}</div>}

          <button onClick={onCancel}>Cancel</button>
          <button onClick={onSave}>Save</button>
        </div>
      </div>
    );
  }
);

/* ✅ THIS LINE FIXES THE WARNING */
Modal.displayName = "Modal";

export default memo(Modal);
