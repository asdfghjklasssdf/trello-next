"use client";
import React from "react";
import { Droppable, Draggable } from "@hello-pangea/dnd";
import { Board } from "@/types/trello";

interface Props {
  board: Board;
  boardIndex: number;
  onBack: () => void;
  onEditBoard: () => void;
  onDeleteBoard: () => void;
  onAddList: (name: string) => void;
  onEditList: (i: number, name: string) => void;
  onDeleteList: (i: number) => void;
  onAddCard: (listIndex: number, name: string) => void;
  onEditCard: (listIndex: number, cardIndex: number, name: string) => void;
  onDeleteCard: (listIndex: number, cardIndex: number) => void;
  openModal: (label: string, cb: (v: string) => void, init?: string) => void;
  onOpenCard: (listIndex: number, cardIndex: number) => void;
}

export default function BoardView(props: Props) {
  const {
    board,
    boardIndex,
    onBack,
    onEditBoard,
    onDeleteBoard,
    onAddList,
    onEditList,
    onDeleteList,
    onAddCard,
    onEditCard,
    onDeleteCard,
    onOpenCard,
  } = props;

  return (
    <div className="board-view">
      {/* ================= HEADER ================= */}
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        <button onClick={onBack}>⬅ Back</button>
        <button onClick={onEditBoard}>✏ Edit Board</button>
        <button onClick={onDeleteBoard}>🗑 Delete Board</button>
        <button onClick={() => onAddList("")}>➕ Add List</button>
      </div>

      {/* ================= LISTS ================= */}
      <Droppable
        droppableId={String(boardIndex)}
        direction="horizontal"
        type="LIST"
      >
        {(p) => (
          <div
            ref={p.innerRef}
            {...p.droppableProps}
            style={{ display: "flex", gap: 16, overflowX: "auto" }}
          >
            {board.lists.map((list, li) => (
              <Draggable
                key={`list-${li}`}
                draggableId={`list-${boardIndex}-${li}`}
                index={li}
              >
                {(p) => (
                  <div
                    ref={p.innerRef}
                    {...p.draggableProps}
                    style={{
                      background: "#ebecf0",
                      padding: 12,
                      width: 260,
                      borderRadius: 8,
                      ...p.draggableProps.style,
                    }}
                  >
                    {/* ===== LIST HEADER ===== */}
                    <div
                      {...p.dragHandleProps}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        marginBottom: 8,
                      }}
                    >
                      <h3>{list.name}</h3>
                      <div>
                        <button
                          onClick={() => onEditList(li, list.name)}
                        >
                          ✏
                        </button>
                        <button
                          onClick={() => onDeleteList(li)}
                        >
                          🗑
                        </button>
                      </div>
                    </div>

                    <button
                      onClick={() => onAddCard(li, "")}
                      style={{ marginBottom: 8 }}
                    >
                      ➕ Add Card
                    </button>

                    {/* ===== CARDS ===== */}
                    <Droppable
                      droppableId={`${boardIndex}-${li}`}
                      type="CARD"
                    >
                      {(p) => (
                        <div
                          ref={p.innerRef}
                          {...p.droppableProps}
                        >
                          {list.cards.map((card, ci) => (
                            <Draggable
                              key={`card-${ci}`}
                              draggableId={`card-${boardIndex}-${li}-${ci}`}
                              index={ci}
                            >
                              {(p) => (
                                <div
                                  ref={p.innerRef}
                                  {...p.draggableProps}
                                  {...p.dragHandleProps}
                                  style={{
                                    background: "#fff",
                                    padding: 8,
                                    borderRadius: 6,
                                    marginBottom: 8,
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    cursor: "pointer",
                                    ...p.draggableProps.style,
                                  }}
                                >
                                  <span
                                    onClick={() =>
                                      onOpenCard(li, ci)
                                    }
                                  >
                                    {card.name}
                                  </span>

                                  <div>
                                    <button
                                      onClick={() =>
                                        onEditCard(
                                          li,
                                          ci,
                                          card.name
                                        )
                                      }
                                    >
                                      ✏
                                    </button>
                                    <button
                                      onClick={() =>
                                        onDeleteCard(li, ci)
                                      }
                                    >
                                      🗑
                                    </button>
                                  </div>
                                </div>
                              )}
                            </Draggable>
                          ))}
                          {p.placeholder}
                        </div>
                      )}
                    </Droppable>
                  </div>
                )}
              </Draggable>
            ))}
            {p.placeholder}
          </div>
        )}
      </Droppable>
    </div>
  );
}
