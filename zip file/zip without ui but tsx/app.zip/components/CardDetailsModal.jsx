"use client";
import { useState, useEffect } from "react";

import "../app/css/popup.css"; // or your popup.css if merged

// ===============================
// HELPERS
// ===============================
const getChecklistProgress = (items = []) => {
  if (!items.length) return 0;
  const done = items.filter(i => i.done).length;
  return Math.round((done / items.length) * 100);
};

const DEFAULT_LABELS = [
  { id: "1", name: "Frontend", color: "#4caf50" },
  { id: "2", name: "Backend", color: "#f97316" },
  { id: "3", name: "UI", color: "#7b61ff" },
  { id: "4", name: "Bug", color: "#ef4444" }
];


const buildDraftFromCard = (card) => {
  let checklists = [];

  if (Array.isArray(card.checklists) && card.checklists.length) {
    checklists = card.checklists;
  } else if (Array.isArray(card.checklist)) {
    checklists = [{ id: "default", title: "Checklist", items: card.checklist }];
  } else {
    checklists = [{ id: "default", title: "Checklist", items: [] }];
  }

  return {
    name: card.name || "",
    description: card.description || "",
    labels: card.labels || [],
    checklists,
    comments: card.comments || [],
    activity: card.activity || [],
    attachments: card.attachments || [],
    startDate: card.startDate || "",
    dueDate: card.dueDate || "",
    location: card.location || "",
    completed: card.completed || false
  };
};

// ===============================
// COMPONENT
// ===============================
export default function CardDetailsModal({ card, onClose, onSave }) {
  const [newLabelName, setNewLabelName] = useState("");
  const [newLabelColor, setNewLabelColor] = useState("#22c55e");
  const [draft, setDraft] = useState(() => buildDraftFromCard(card));

 
const [labelManagerOpen, setLabelManagerOpen] = useState(false);

  const [commentInput, setCommentInput] = useState("");
  const [pendingChecklistItems, setPendingChecklistItems] = useState({});
const [availableLabels, setAvailableLabels] = useState(() => {
  if (typeof window === "undefined") return [];

  const stored = localStorage.getItem("labels");
  if (stored) {
    return JSON.parse(stored);
  }

  const defaults = [
    { id: "1", name: "Frontend", color: "#4caf50" },
    { id: "2", name: "Backend", color: "#f97316" },
    { id: "3", name: "UI", color: "#7b61ff" },
    { id: "4", name: "Bug", color: "#ef4444" }
  ];

  localStorage.setItem("labels", JSON.stringify(defaults));
  return defaults;
});



  
  const log = (text) => {
    setDraft(d => ({
      ...d,
      activity: [
        ...d.activity,
        { text, time: new Date().toLocaleString() }
      ]
    }));
  };
 
    /* ===============================
     LABEL CRUD
  ================================ */
 const addLabel = () => {
  if (!newLabelName.trim()) return;

  const newLabel = {
    id: Date.now().toString() + Math.random().toString(36).slice(2),
    name: newLabelName,
    color: newLabelColor
  };

  const updated = [...availableLabels, newLabel];
  setAvailableLabels(updated);
  localStorage.setItem("labels", JSON.stringify(updated));

  log(`Label "${newLabelName}" created`);
  setNewLabelName("");
};


  const updateLabel = (id, updates) => {
    const updated = availableLabels.map(l =>
      l.id === id ? { ...l, ...updates } : l
    );

    setAvailableLabels(updated);
    localStorage.setItem("labels", JSON.stringify(updated));

    setDraft(d => ({
      ...d,
      labels: d.labels.map(l =>
        l.id === id ? { ...l, ...updates } : l
      )
    }));

    log("Label updated");
  };

  const deleteLabel = (id) => {
    const updated = availableLabels.filter(l => l.id !== id);
    setAvailableLabels(updated);
    localStorage.setItem("labels", JSON.stringify(updated));

    setDraft(d => ({
      ...d,
      labels: d.labels.filter(l => l.id !== id)
    }));

    log("Label deleted");
  };

 
  
  const toggleLabel = (label) => {
    setDraft(d => {
      const exists = d.labels.some(l => l.name === label.name);
      log(`Label "${label.name}" ${exists ? "removed" : "added"}`);
      return {
        ...d,
        labels: exists
          ? d.labels.filter(l => l.name !== label.name)
          : [...d.labels, label]
      };
    });
  };

   const toggleCardCompleted = () => { // ✅ ADDED
    setDraft(d => {
      log(d.completed ? "Card marked incomplete" : "Card marked completed");
      return { ...d, completed: !d.completed };
    });
  };
  const toggleChecklistByUser = (clId) => {
    setDraft(d => {
      const cl = d.checklists.find(c => c.id === clId);
      if (!cl) return d;

      const allDone = cl.items.every(i => i.done);

      return {
        ...d,
        checklists: d.checklists.map(c =>
          c.id === clId
            ? {
                ...c,
                items: c.items.map(it => ({
                  ...it,
                  done: !allDone
                }))
              }
            : c
        )
      };
    });

    log("Checklist toggled by user");
  };
 
  const toggleChecklistItem = (clId, index) => {
    setDraft(d => {
      const item = d.checklists.find(c => c.id === clId)?.items[index];
      log(item?.done ? "Checklist item reopened" : "Checklist item completed");

      return {
        ...d,
        checklists: d.checklists.map(cl =>
          cl.id === clId
            ? {
                ...cl,
                items: cl.items.map((it, i) =>
                  i === index ? { ...it, done: !it.done } : it
                )
              }
            : cl
        )
      };
    });
  };

 
  const addComment = (text) => {
    if (!text.trim()) return;

    setDraft(d => ({
      ...d,
      comments: [
        ...d.comments,
        { text, time: new Date().toLocaleString() }
      ]
    }));

    log("Comment added");
    setCommentInput("");
  };

 
  const addAttachment = (file) => {
    if (!file) return;

    setDraft(d => ({
      ...d,
      attachments: [...d.attachments, file.name]
    }));

    log(`Attachment "${file.name}" added`);
  };

 
  const commitPendingInputs = () => {
    let updated = { ...draft };

    if (commentInput.trim()) {
      updated.comments = [
        ...updated.comments,
        { text: commentInput, time: new Date().toLocaleString() }
      ];
      log("Comment added");
    }

    updated.checklists = updated.checklists.map(cl => {
      const pending = pendingChecklistItems[cl.id];
      if (pending?.trim()) {
        log("Checklist item added");
        return {
          ...cl,
          items: [...cl.items, { text: pending, done: false }]
        };
      }
      return cl;
    });

    return updated;
  };

 
  const saveAll = () => {
    const finalDraft = commitPendingInputs();

    onSave({
      ...card,
      ...finalDraft,
      checklists: finalDraft.checklists,
      checklist: undefined
    });

    onClose();
  };
  
  return (
    <div className="modalOverlay" onMouseDown={onClose}>
      <div className="cardModal" onMouseDown={e => e.stopPropagation()}>

        <div className="cardModalHeader">
          <span
            className={`cardCompleteToggle ${draft.completed ? "done" : ""}`}
            onClick={() => setDraft(d => ({ ...d, completed: !d.completed }))}
          >
            {draft.completed ? "✓" : "○"}
          </span>

          <input
            className={`cardTitle ${draft.completed ? "titleDone" : ""}`}
            value={draft.name}
            onChange={e => setDraft(d => ({ ...d, name: e.target.value }))}
          />

          <button className="closeBtn" onClick={onClose}>✕</button>
        </div>
        

        <div className="cardModalBody">
          <div className="cardLeft">
<h4>Labels</h4>

<div className="labelsRow">
  {availableLabels.map(l => (
    <span
      key={l.id}
      className="labelChip"
      style={{
        background: l.color,
        opacity: draft.labels.some(x => x.id === l.id) ? 1 : 0.3
      }}
      onClick={() => toggleLabel(l)}
    >
      {l.name}
    </span>
  ))}
</div>

<button
  className="manageLabelsBtn"
  onClick={() => setLabelManagerOpen(true)}
>
  + Manage labels
</button>
{labelManagerOpen && (
  <div
    className="labelManagerOverlay"
    onClick={() => setLabelManagerOpen(false)} 
  >
    <div
      className="labelManager"
      onClick={e => e.stopPropagation()} 
    >
      <div className="labelManagerHeader">
        <h4>Manage Labels</h4>
        <button onClick={() => setLabelManagerOpen(false)}>✕</button>
      </div>

      <div className="labelAddRow">
        <input
          placeholder="Label name"
          value={newLabelName}
          onChange={e => setNewLabelName(e.target.value)}
        />
        <input
          type="color"
          value={newLabelColor}
          onChange={e => setNewLabelColor(e.target.value)}
        />
        <button onClick={addLabel}>+</button>
      </div>

      {availableLabels.map(l => (
        <div key={l.id} className="labelRow">
          <input
            value={l.name}
            onChange={e =>
              updateLabel(l.id, { name: e.target.value })
            }
          />
          <input
            type="color"
            value={l.color}
            onChange={e =>
              updateLabel(l.id, { color: e.target.value })
            }
          />
          <button onClick={() => deleteLabel(l.id)}>🗑</button>
        </div>
      ))}
    </div>
  </div>
)}


            <h4>Description</h4>
            <textarea
              value={draft.description}
              onChange={e => setDraft(d => ({ ...d, description: e.target.value }))}
            />

            <h4>Checklist</h4>
            {draft.checklists.map(cl => {
              const progress = getChecklistProgress(cl.items);

              return (
                <div key={cl.id} className="checklistBox">

                  <div className="checklistHeader">
                    <span>{cl.title}</span>
                    <span>{progress}%</span>
                  </div>

                  <div
                    className="progressBar clickable"
                    onClick={() => toggleChecklistByUser(cl.id)}
                    title="Click to toggle checklist"
                  >
                    <div
                      className="progressFill"
                      style={{ width: `${progress}%` }}
                    />
                  </div>

                  {cl.items.map((item, i) => (
                    <div key={i} className="checkItem">
                      <input
                        type="checkbox"
                        checked={item.done}
                        onChange={() => toggleChecklistItem(cl.id, i)}
                      />
                      <span className={item.done ? "done" : ""}>
                        {item.text}
                      </span>
                    </div>
                  ))}

                  <input
                    className="commentInput"
                    placeholder="Add checklist item…"
                    value={pendingChecklistItems[cl.id] || ""}
                    onChange={e =>
                      setPendingChecklistItems(p => ({
                        ...p,
                        [cl.id]: e.target.value
                      }))
                    }
                    onKeyDown={e => {
                      if (e.key === "Enter") {
                        setDraft(d => ({
                          ...d,
                          checklists: d.checklists.map(x =>
                            x.id === cl.id
                              ? {
                                  ...x,
                                  items: [
                                    ...x.items,
                                    { text: pendingChecklistItems[cl.id], done: false }
                                  ]
                                }
                              : x
                          )
                        }));
                        log("Checklist item added");
                        setPendingChecklistItems(p => ({ ...p, [cl.id]: "" }));
                      }
                    }}
                  />
                </div>
              );
            })}

            <h4>Attachments</h4>
            {draft.attachments.map((a, i) => (
              <div key={i} className="commentItem">{a}</div>
            ))}
            <input type="file" onChange={e => addAttachment(e.target.files[0])} />

            <h4>Comments</h4>
            {draft.comments.map((c, i) => (
              <div key={i} className="commentItem">
                {c.text}
                <div style={{ fontSize: 11, opacity: 0.6 }}>{c.time}</div>
              </div>
            ))}

            <input
              className="commentInput"
              placeholder="Write a comment…"
              value={commentInput}
              onChange={e => setCommentInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && addComment()}
            />

           
          </div>

          <div className="cardRight">
            <h4>Start date</h4>
            <input
              type="date"
              value={draft.startDate}
              onChange={e => {
                setDraft(d => ({ ...d, startDate: e.target.value }));
                log("Start date updated");
              }}
            />

            <h4>Due date</h4>
            <input
              type="date"
              value={draft.dueDate}
              onChange={e => {
                setDraft(d => ({ ...d, dueDate: e.target.value }));
                log("Due date updated");
              }}
            />

            <h4>Location</h4>
            <input
              type="text"
              value={draft.location}
              onChange={e => {
                setDraft(d => ({ ...d, location: e.target.value }));
                log("Location updated");
              }}
            />

           <h4>Activity</h4>

          <div className="activityScroll">
            {draft.activity.map((a, i) => (
              <div key={i} className="commentItem">
                {a.text}
                <div style={{ fontSize: 11, opacity: 0.6 }}>
                  {a.time}
                </div>
              </div>
            ))}
          </div>

          </div>
        </div>

        <div className="cardModalFooter">
          <button className="cancelBtn" onClick={onClose}>Cancel</button>
          <button className="saveBtn" onClick={saveAll}>Save</button>
        </div>
      </div>
    </div>
  );
}